"""Store the version for setup.py and the module itself."""
__version__ = "0.23.0"  # keep in sync with ../setup.py


from cryptography.fernet import Fernet
from sqlalchemy import create_engine
import sqlalchemy as sa
import pandas as pd
import urllib
import os
import traceback

#You can point this to any Python configutaion file you may have. 
#from kcf_config import Config

#Key must be in binary string format. IE: b"Key"
#You can change this if you want a different encryption Key for your application
CryptKey = b"2FaT6PqdFoVs6-uRIm_B-Cn4dTQfpgXOofv1ZQQpIpo="
#Dev
#dbConnectionEncoded='gAAAAABdERfytjErtmp2QoeehrdcYMZqZsDAu5n_-WrQvfDzqryBiwljr7qu1SZdAtRAYnKjGPwAs60KPS8VYXxeE6kTdZ7d1YaZyq2u11o6_3-hpNXQJiR_J_Qbl6EMZ8dFSZQyNaNEROS9NFqfqPPfKNOgcVakR3n2J5vKgLIpHc3xQXQJ6GuTdy-YO7Tu7F_pemBl_hjlNPstM89bIMn4XRv3SOVHs8GQt01ZYGMNf5zV5yXgYac='
#Prod
#dbConnectionEncoded='gAAAAABdudn-D3I4nswcQ-xr5zuqxdpSWelxw6KbuKS4Wz6fZrPwZ4duNHzHrjy2q-p6kmVjPrmV9rv8SL5-jyzNlulTK6xVGJPOBEhxQt1dyklzQYk6ycIH7MSS8Z8mrcg3kPjj4Dl7NX0z28L_zaiRu2jmeSe0LfBmQrMHZHN5Tyl5Uy5d1VYtAF_udgMxBeFBwi2-8XAgwWVWUf9k9oCfVanIGHewcKIeJyYVTO_8Po9dpKxF5uc='

#PROD with pymysql
dbConnectionEncoded='gAAAAABelzcjkahACv-evk11ThbAIOmqcEFf938o5QxE0GJ0rKMKm-JINersc71pDSlEtC0598a5GjCtbdP5UmLS9jjhSMntICTDJwnFsNfZahOmDopSyIYPAUC6JZ44tBGbmMp2cbfqjN2f70iwoNj523rfgPS1t2v6Ya0w6MEW69QBpqFROQ2RjJDc_spyUflBIolBLQaBKLp_Kytux4yLetT4J43CYL-vtj4YhkHNZIMJhmso3lM='

def GenerateKey(toPrint = False):
    key = Fernet.generate_key()
    if toPrint:
        print("\nDecryption Key: ")
        print(key.decode())
    return key.decode();

def Encrypt(strToEncrypt, toPrint = False):         
    cipher = Fernet(CryptKey)
    try:
        cipher_text  = cipher.encrypt(strToEncrypt.encode())
        if(toPrint):
            print("\nEncoded Text")
            print(cipher_text)
    except Exception as e:
        print("\nAn error occured:")
        print(repr(e))
        traceback.print_tb(e.__traceback__)
    return cipher_text;

def Decrypt(strToDecrypt, toPrint = False):
    cipher = Fernet(CryptKey)  
    try:
        uncipher_text = cipher.decrypt(strToDecrypt.encode())
        if(toPrint):
            print("\nDecoded Text:")
            print (uncipher_text.decode())
        return uncipher_text.decode()
    except Exception as e:
        print("\nAn error occured:")
        print(repr(e))
        traceback.print_tb(e.__traceback__)
    return

def GetAWSKeyByName(ConnectionName):
    Key = ""
    Secret = ""
    try:        
        redshift_engine = create_engine(Decrypt(dbConnectionEncoded))
        
        sql=f"""SELECT UserName, Password
                FROM data_alerts.data_flow_alerts_connections
                WHERE LOWER(ConnectionName) = '{str(ConnectionName).lower()}'
                AND Type = 'AWSKey'
                LIMIT 1               
            """
        with redshift_engine.connect() as conn, conn.begin():
            df = pd.read_sql(sql, conn)
            if(len(df)>0):
                 for idx, row in df.iterrows():
                    Key = Decrypt(row['UserName'])
                    Secret = Decrypt(row['Password'])

    except Exception as e:
            print("\nAn error occured:")
            print(repr(e))
            traceback.print_tb(e.__traceback__)
    
    finally:
        redshift_engine.dispose()
    
    return Key, Secret


def GetConnectionStringParamsByName(ConnectionName):
    Server = ""
    Database = ""
    UserName = ""
    Password = ""
    Port = ""
    Type = ""
    try:        
        redshift_engine = create_engine(Decrypt(dbConnectionEncoded))
        
        sql=f"""SELECT ConnServer, ConnDatabase, UserName, Password, Port, Type
                FROM data_alerts.data_flow_alerts_connections
                WHERE LOWER(ConnectionName) = '{str(ConnectionName).lower()}'
                AND Type <> 'AWSKey'
                LIMIT 1               
            """
        with redshift_engine.connect() as conn, conn.begin():
            df = pd.read_sql(sql, conn)
            if(len(df)>0):
                 for idx, row in df.iterrows():
                    Server = Decrypt(row['ConnServer'])
                    Database = Decrypt(row['ConnDatabase'])
                    UserName = Decrypt(row['UserName'])
                    Password = Decrypt(row['Password'])
                    Port = row['Port']
                    Type = row['Type']

    except Exception as e:
            print("\nAn error occured:")
            print(repr(e))
            traceback.print_tb(e.__traceback__)
    
    finally:
        redshift_engine.dispose()
    
    return Server, Database, UserName, Password, Port, Type

def GetConnectionStringByName(ConnectionName, Format = "pythonsqlalchemy", Driver = "ODBC Driver 17 for SQL Server"):

    rtnVal = ""
    

    try:
        Server, Database, UserName, Password, Port, Type = GetConnectionStringParamsByName(ConnectionName)

        #postgresql://USERNAME:PASSWORD@gp-rs-datalake-prod.c6kmgopkqubk.us-east-1.redshift.amazonaws.com:5439/edadatalake
        if(Format.lower() == "pythonsqlalchemy"):
            ##Old version of query building for non MSSQL Connections. 
            #rtnVal= f"""{Type}://{UserName}:{Password}@{Server}:{Port}/{Database}"""
            
            
            if Type == "mssql+pyodbc":
                connection_uri = sa.engine.url.URL(
                "mssql+pyodbc",
                username=UserName,
                password=Password,
                host=Server,
                database=Database,  # required; not an empty string
                query={"driver": Driver}
            )
            else:
            
                connection_uri = sa.engine.url.URL(
                    Type,
                    username=UserName,
                    password=Password,
                    host=Server,
                    port=Port,
                    database=Database  # required; not an empty string                
                    
                )
            
            rtnVal = connection_uri
        #params = urllib.parse.quote_plus("DRIVER={SQL Server Native Client 10.0};SERVER=dagger;DATABASE=test;UID=user;PWD=password")
        #engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)
        if(Format.lower() == "mssqlserver"):

            connection_uri = sa.engine.url.URL(
                "mssql+pyodbc",
                username=UserName,
                password=Password,
                host=Server,
                database=Database,  # required; not an empty string
                query={"driver": Driver}
            )
            #print(connection_uri)
            
            rtnVal = connection_uri
            #sql_engine = create_engine(connection_uri, fast_executemany=True)
        
            
    except Exception as e:
            print("\nAn error occured:")
            print(repr(e))
            traceback.print_tb(e.__traceback__)

    return rtnVal

def ListConnectionNames():
    rtnVal =[]
    ConnID = ""
    ConnectionName = ""
    Server = ""
    Database = ""
    UserName = ""
    Password = ""
    Port = ""
    Type = ""    
       
    
    try:        
        redshift_engine = create_engine(Decrypt(dbConnectionEncoded))
        
        sql=f"""SELECT ConnID, ConnectionName, ConnServer, ConnDatabase, UserName, Password, Port, Type
                FROM data_alerts.data_flow_alerts_connections
                WHERE Type <> 'AWSKey'                
            """
        with redshift_engine.connect() as conn, conn.begin():
            df = pd.read_sql(sql, conn)
            if(len(df)>0):
                for idx, row in df.iterrows():
                    ConnID = row['ConnID']       
                    ConnectionName = row['ConnectionName']
                    Server = Decrypt(row['ConnServer'])
                    Database = Decrypt(row['ConnDatabase'])
                    UserName = Decrypt(row['UserName'])
                    Password = Decrypt(row['Password'])
                    Port = row['Port']
                    Type = row['Type']
                    rtnVal.append({'ConnID' : ConnID, 'ConnectionName' : ConnectionName, 'Server' : Server, 'Database' : Database, 'UserName' : UserName, 'Password' : Password, 'Port' : Port, 'Type' : Type})


    except Exception as e:
            print("\nAn error occured in ListConnectionNames:")
            print(repr(e))
            traceback.print_tb(e.__traceback__)
    
    finally:
        redshift_engine.dispose()
    
    return rtnVal 

def ListAWSKeys():
    rtnVal =[]
    ConnID = ""
    ConnectionName = ""    
    UserName = ""
    Password = ""    
    Type = ""    
       
    
    try:        
        redshift_engine = create_engine(Decrypt(dbConnectionEncoded))
        
        sql=f"""SELECT ConnID, ConnectionName, UserName, Password, Type
                FROM data_alerts.data_flow_alerts_connections                
                WHERE Type = 'AWSKey'                                
            """
        with redshift_engine.connect() as conn, conn.begin():
            df = pd.read_sql(sql, conn)
            if(len(df)>0):
                for idx, row in df.iterrows():
                    ConnID = row['ConnID']       
                    ConnectionName = row['ConnectionName']                    
                    UserName = Decrypt(row['UserName'])
                    Password = Decrypt(row['Password'])
                    Type = row['Type']
                    rtnVal.append({'ConnID' : ConnID, 'ConnectionName' : ConnectionName, 'UserName' : UserName, 'Password' : Password, 'Type' : Type})


    except Exception as e:
            print("\nAn error occured in ListAWSKeys:")
            print(repr(e))
            traceback.print_tb(e.__traceback__)
    
    finally:
        redshift_engine.dispose()
    
    return rtnVal






